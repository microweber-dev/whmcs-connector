# whmcs-connector

This module allows you to login with your hosting account username and password.
