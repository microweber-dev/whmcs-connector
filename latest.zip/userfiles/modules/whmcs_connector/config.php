<?php

$config = array();
$config['name'] = "WHMCS Login";
$config['author'] = "Microweber";
$config['description'] = "Allows you to login with WHMCS account";
$config['website'] = "http://microweber.com/"; 
$config['help'] = "http://microweber.com/"; 
$config['version'] = 0.2;
$config['ui'] = false; 
$config['ui_admin'] = false;
$config['position'] = 210;
$config['categories'] = "users";    
 